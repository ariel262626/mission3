//
// Created by ariel on 29/11/16.
//

#ifndef MISSION2_LUXURYCAB_H
#define MISSION2_LUXURYCAB_H


#include "StandartCab.h"

class LuxuryCab : public CabBase {
public:
    LuxuryCab();
};


#endif //MISSION2_LUXURYCAB_H
