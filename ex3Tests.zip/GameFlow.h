//
// Created by ariel on 30/11/16.
//

#ifndef MISSION2_GAMEFLOW_H
#define MISSION2_GAMEFLOW_H


class GameFlow {

};


#endif //MISSION2_GAMEFLOW_H
