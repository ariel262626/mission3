//
// Created by ariel on 29/11/16.
//
#include <iostream>
#include "Passenger.h"
#include "CabBase.h"

using namespace std;

#ifndef MISSION2_STANDARTCAB_H
#define MISSION2_STANDARTCAB_H

class StandartCab: public CabBase{

public:
};


#endif //MISSION2_STANDARTCAB_H
