//
// Created by ariel on 29/11/16.
//

#include "LuxuryCab.h"

LuxuryCab::LuxuryCab() {}

